import json
import requests
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Extract S3 bucket and object key from the event
    try:
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']
        event_type = "upload"  # or set dynamically based on your event trigger
    except KeyError as e:
        logger.error(f"Error parsing S3 event: {e}")
        return {
            "statusCode": 400,
            "body": json.dumps(f"Error parsing S3 event: {str(e)}")
        }

    # Set up the payload for the FastAPI endpoint
    payload = {
        "bucket_name": bucket_name,
        "file_key": file_key,
        "event_type": event_type
    }

    # Define the FastAPI endpoint URL
    fastapi_url = "http://192.168.3.50:8510/process_s3_event"

    # Make the HTTP POST request to the FastAPI endpoint
    try:
        response = requests.post(fastapi_url, json=payload)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error calling FastAPI endpoint: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps(f"Error calling FastAPI endpoint: {str(e)}")
        }

    return {
        "statusCode": response.status_code,
        "body": json.dumps(f"FastAPI response: {response.json()}")
    }
